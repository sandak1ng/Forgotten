﻿public interface IGraphNode
{
    int GetDistance(IGraphNode other);
}

