﻿using UnityEngine;
using System.Collections;
namespace TileEditor
{
    #region Enum
    public enum CollisionType
    {
        None,
        Box,
        Polygon,
        Circle
    }
    #endregion
}
